# Password generator

A Pen created on CodePen.

Original URL: [https://codepen.io/alexajoy-dotcom/pen/WbGpRpO](https://codepen.io/alexajoy-dotcom/pen/WbGpRpO).

